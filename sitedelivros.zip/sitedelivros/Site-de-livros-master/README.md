Execute cada aquivo HTML no navegador Chrome.
